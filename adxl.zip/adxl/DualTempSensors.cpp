#include "DualTempSensors.h"

#define TEMP_MIN -10
#define TEMP_MAX 120
#define DEVICE_DISCONNECTED_C -127.0

DualTempSensors::DualTempSensors(uint8_t pin1, uint8_t pin2)
  : oneWire1(pin1), oneWire2(pin2),
    sensor1(&oneWire1), sensor2(&oneWire2),
    temp1(0), temp2(0) {}

void DualTempSensors::begin() {
  sensor1.begin();
  sensor2.begin();

  // Set lower resolution for faster readings
  sensor1.setResolution(9);  // 9-bit = ~93.75ms
  sensor2.setResolution(9);
}

void DualTempSensors::update() {
  sensor1.requestTemperatures();
  sensor2.requestTemperatures();

  // Wait until conversions are ready (non-blocking)
  unsigned long start = millis();
  while (!sensor1.isConversionComplete() || !sensor2.isConversionComplete()) {
    if (millis() - start > 100) break; // Timeout
    delay(1);
  }

  bool sensor1Connected, sensor2Connected;

  temp1 = readTemperature(sensor1, sensor1Connected);
  temp2 = readTemperature(sensor2, sensor2Connected);
}

float DualTempSensors::readTemperature(DallasTemperature& sensor, bool& connected) {
  float temperature = sensor.getTempCByIndex(0);
  if (temperature != DEVICE_DISCONNECTED_C &&
      temperature >= TEMP_MIN && temperature <= TEMP_MAX) {
    connected = true;
    return temperature;
  }

  connected = false;
  return 0;
}

float DualTempSensors::getTemp1() { return temp1; }
float DualTempSensors::getTemp2() { return temp2; }
