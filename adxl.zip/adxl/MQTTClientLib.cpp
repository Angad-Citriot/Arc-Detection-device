#include "MQTTClientLib.h"
#include <Arduino.h>

char jsonData[JSON_BUFFER_SIZE];

MQTTClientLib::MQTTClientLib(PubSubClient& client, const char* topic)
  : _client(client), _topic(topic) {}

void MQTTClientLib::reconnectMQTT() {
  while (!_client.connected()) {
    if (_client.connect(_clientId.c_str())) {
      // Connected
    } else {
      delay(5000);
    }
  }
}

void MQTTClientLib::begin(const String& clientId) {
  _clientId = clientId; // Save it for reconnect use
  _client.setBufferSize(MQTT_MAX_PACKET_SIZE);
}

void MQTTClientLib::loop() {
  if (!_client.connected()) {
    reconnectMQTT();
  }
  _client.loop();
}

void MQTTClientLib::publishJSON(float noise, float accelX, float accelY, float accelZ,
                                float temperature1, float temperature2, float temperature3,
                                float master_TH1, float master_TH2, float master_TH3) {
  snprintf(jsonData, sizeof(jsonData),
    "{\"temp\":0,\"noise\":%.2f,\"Accel_X\":%.2f,\"Accel_Y\":%.2f,\"Accel_Z\":%.2f,"
    "\"humidity\":0,\"pressure\":0,\"LPG\":0,\"CO\":0,\"smoke\":0,\"time\":0,"
    "\"Therm1\":%.1f,\"Therm2\":%.1f,\"Therm3\":%.1f,\"fuel\":0,"
    "\"Longitude\":0,\"Latitude\":0,\"speed\":0,"
    "\"status\":0,\"master_TH1\":%.1f,\"master_TH2\":%.1f,\"master_TH3\":%.1f}",
    noise, accelX, accelY, accelZ,
    temperature1, temperature2, temperature3,
    master_TH1, master_TH2, master_TH3);

  _client.publish(_topic, jsonData);
}

