// VibrationSensor.h
#pragma once
#include <Arduino.h>

class VibrationSensor {
public:
  VibrationSensor(int xPin, int yPin, int zPin, int noisePin, float sampleRateHz = 200.0);
  void begin();
  void update();

  float getRmsX() const;
  float getRmsY() const;
  float getRmsZ() const;
  float getPeakX() const;
  float getPeakY() const;
  float getPeakZ() const;
  float getNoiseRms() const;

private:
  int _xPin, _yPin, _zPin, _noisePin;
  float _sampleRate;
  static const int BUFFER_SIZE = 400;

  float _xBuf[BUFFER_SIZE];
  float _yBuf[BUFFER_SIZE];
  float _zBuf[BUFFER_SIZE];
  float _noiseBuf[BUFFER_SIZE];

  float _offsetX, _offsetY, _offsetZ;
  float _alphaHP, _alphaLP;
  float _peakX, _peakY, _peakZ;
  unsigned long _lastPeakReset;

  float _xPrevHP[3] = {0}, _yPrevHP[3] = {0};
  float _yPrevLP[3] = {0};

  float _rmsX = 0, _rmsY = 0, _rmsZ = 0;
  float _rmsNoise = 0;

  void calibrate();
  float filterHP(float input, int axis);
  float filterLP(float input, int axis);
  float vectorDot(float *a, float *b, int n);
};