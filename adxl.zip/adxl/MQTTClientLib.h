#ifndef MQTT_CLIENT_LIB_H
#define MQTT_CLIENT_LIB_H

#include <PubSubClient.h>

#define MQTT_MAX_PACKET_SIZE 1024
#define JSON_BUFFER_SIZE 1024

class MQTTClientLib {
public:
  MQTTClientLib(PubSubClient& client, const char* topic);
  void begin(const String& clientId);  // updated prototype
  void loop();
  void publishJSON(float noise, float accelX, float accelY, float accelZ,
                   float temperature1, float temperature2, float temperature3,
                   float master_TH1, float master_TH2, float master_TH3);

private:
  PubSubClient& _client;
  const char* _topic;
  String _clientId;  // store unique client ID
  void reconnectMQTT();
};


#endif
