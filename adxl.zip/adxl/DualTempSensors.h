#ifndef DUAL_TEMP_SENSORS_H
#define DUAL_TEMP_SENSORS_H

#include <OneWire.h>
#include <DallasTemperature.h>

class DualTempSensors {
  public:
    DualTempSensors(uint8_t pin1, uint8_t pin2);
    void begin();
    void update();
    float getTemp1();
    float getTemp2();

  private:
    OneWire oneWire1;
    OneWire oneWire2;
    DallasTemperature sensor1;
    DallasTemperature sensor2;

    float temp1;
    float temp2;

    float readTemperature(DallasTemperature& sensor, bool& connected);
};

#endif
