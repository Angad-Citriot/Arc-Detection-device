#include "VibrationSensor.h"
#include <math.h>

VibrationSensor::VibrationSensor(int xPin, int yPin, int zPin, int noisePin, float sampleRateHz)
  : _xPin(xPin), _yPin(yPin), _zPin(zPin), _noisePin(noisePin), _sampleRate(sampleRateHz),
    _offsetX(0), _offsetY(0), _offsetZ(0), _peakX(0), _peakY(0), _peakZ(0), _lastPeakReset(0) {}

void VibrationSensor::begin() {
  analogReadResolution(12);

  float rcHP = 1.0 / (2 * PI * 0.5);
  _alphaHP = rcHP / (rcHP + 1.0 / _sampleRate);

  float rcLP = 1.0 / (2 * PI * 100);
  _alphaLP = 1.0 / (1.0 + rcLP * _sampleRate);

  calibrate();
  _lastPeakReset = millis();
}

void VibrationSensor::calibrate() {
  const int calSamples = 500;
  float sumX = 0, sumY = 0, sumZ = 0;

  for (int i = 0; i < calSamples; i++) {
    sumX += analogRead(_xPin);
    sumY += analogRead(_yPin);
    sumZ += analogRead(_zPin);
    delay(10);
  }

  const float VREF = 3.3;
  const float SENS = 0.3;
  const float G2MS2 = 9806.65;

  _offsetX = ((sumX / calSamples * VREF) / 4095.0 - 1.65) / SENS * G2MS2;
  _offsetY = ((sumY / calSamples * VREF) / 4095.0 - 1.65) / SENS * G2MS2;
  _offsetZ = ((sumZ / calSamples * VREF) / 4095.0 - 1.65) / SENS * G2MS2;
}

void VibrationSensor::update() {
  const float VREF = 3.3;
  const float SENS = 0.3;
  const float G2MS2 = 9806.65;

  unsigned long ts = micros();
  for (int i = 0; i < BUFFER_SIZE; i++) {
    float x = ((analogRead(_xPin) * VREF / 4095.0 - 1.65) / SENS) * G2MS2 - _offsetX;
    float y = ((analogRead(_yPin) * VREF / 4095.0 - 1.65) / SENS) * G2MS2 - _offsetY;
    float z = ((analogRead(_zPin) * VREF / 4095.0 - 1.65) / SENS) * G2MS2 - _offsetZ;

    x = filterHP(x, 0); y = filterHP(y, 1); z = filterHP(z, 2);
    x = filterLP(x, 0); y = filterLP(y, 1); z = filterLP(z, 2);

    float abs_x = fabs(x), abs_y = fabs(y), abs_z = fabs(z);
    if (abs_x > _peakX) _peakX = abs_x;
    if (abs_y > _peakY) _peakY = abs_y;
    if (abs_z > _peakZ) _peakZ = abs_z;

    _xBuf[i] = x; _yBuf[i] = y; _zBuf[i] = z;

    float noiseV = analogRead(_noisePin) * VREF / 4095.0;
    _noiseBuf[i] = noiseV;

    while (micros() - ts < (i + 1) * (1000000 / _sampleRate));
  }

  _rmsX = sqrt(vectorDot(_xBuf, _xBuf, BUFFER_SIZE) / BUFFER_SIZE);
  _rmsY = sqrt(vectorDot(_yBuf, _yBuf, BUFFER_SIZE) / BUFFER_SIZE);
  _rmsZ = sqrt(vectorDot(_zBuf, _zBuf, BUFFER_SIZE) / BUFFER_SIZE);
  _rmsNoise = sqrt(vectorDot(_noiseBuf, _noiseBuf, BUFFER_SIZE) / BUFFER_SIZE);

  if (millis() - _lastPeakReset >= 1000) {
    _peakX = _peakY = _peakZ = 0;
    _lastPeakReset = millis();
  }
}

float VibrationSensor::filterHP(float input, int axis) {
  float output = _alphaHP * (_yPrevHP[axis] + input - _xPrevHP[axis]);
  _xPrevHP[axis] = input;
  _yPrevHP[axis] = output;
  return output;
}

float VibrationSensor::filterLP(float input, int axis) {
  float output = _yPrevLP[axis] + _alphaLP * (input - _yPrevLP[axis]);
  _yPrevLP[axis] = output;
  return output;
}

float VibrationSensor::vectorDot(float *a, float *b, int n) {
  float sum = 0;
  for (int i = 0; i < n; i++) sum += a[i] * b[i];
  return sum;
}

float VibrationSensor::getRmsX() const { return _rmsX; }
float VibrationSensor::getRmsY() const { return _rmsY; }
float VibrationSensor::getRmsZ() const { return _rmsZ; }
float VibrationSensor::getPeakX() const { return _peakX; }
float VibrationSensor::getPeakY() const { return _peakY; }
float VibrationSensor::getPeakZ() const { return _peakZ; }
float VibrationSensor::getNoiseRms() const { return _rmsNoise; }